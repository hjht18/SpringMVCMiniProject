package com.project.mini.product;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project.mini.member.MemberVO;

@Controller
@RequestMapping("/product")
public class ProductController {
	
	@RequestMapping("/test")
	public String selectMemberAddress(MemberVO vo) {
		
		return "product/productTest";
	}

}
