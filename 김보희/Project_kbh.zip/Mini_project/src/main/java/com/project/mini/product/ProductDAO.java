package com.project.mini.product;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ProductDAO {
	
	private SqlSessionTemplate mybatis;

	@Autowired
	public ProductDAO(SqlSessionTemplate mybatis) {
		this.mybatis = mybatis;
	}
	
	
}
