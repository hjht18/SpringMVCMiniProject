package com.project.mini.product;

public interface ProductService {

}
