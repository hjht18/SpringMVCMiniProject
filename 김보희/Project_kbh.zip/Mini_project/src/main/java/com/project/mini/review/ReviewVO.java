package com.project.mini.review;

public class ReviewVO {

}
