package com.project.mini.review;

public interface ReviewService {

}
