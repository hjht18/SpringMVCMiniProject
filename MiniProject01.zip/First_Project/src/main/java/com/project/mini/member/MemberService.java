package com.project.mini.member;

public interface MemberService {
	public void login(MemberVO ub);
}
