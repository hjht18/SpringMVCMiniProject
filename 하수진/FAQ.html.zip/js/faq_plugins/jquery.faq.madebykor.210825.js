$.fn.extend({
		faq: function(){
			var ts = $(this);
			// faq 플러그인을 적용한 요소의 개수만큼 함수를 실행합니다.
			$.each(ts, function(i, o){
				// faq 플러그인을 적용한 요소에 포함되어 있는
				// 버튼에 클릭 이벤트를 등록합니다.
				$("button", o).on("click", tabmenu);
				function tabmenu(){

					// $("요소 선택").next()
					// 선택한 요소를 기준으로 다음에 오는 형제 요소만 선택합니다.
					if($(this).parent().next().is(":hidden")){
						$("li>div:visible", o).hide();

						// $("요소 선택").next()
						// 선택한 요소를 기준으로 다음에 오는 형제 요소만 선택합니다.
						$(this).parent().next().show();
					}else{
						$("li>div:visible", o).hide();
					}
				}
			});
		}
	});