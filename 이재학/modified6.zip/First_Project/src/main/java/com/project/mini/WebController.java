package com.project.mini;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

// 웹페이지 경로를 처리하는 컨트롤러

@Controller
public class WebController {

	// 내비바의 info
	@RequestMapping("/info.do")
	public String goInfo() {
		return "info";
	}
	
	// 내비바의 FAQ
	@RequestMapping("/faq.do")
	public String goFaq() {
		return "faq";
	}
}
