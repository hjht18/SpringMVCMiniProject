/*!
* Start Bootstrap - Landing Page v6.0.3 (https://startbootstrap.com/theme/landing-page)
* Copyright 2013-2021 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-landing-page/blob/master/LICENSE)
*/
// This file is intentionally blank
// Use this file to add JavaScript to your project

$(document).ready(function(){
    $("#tooltip").mouseover(function(){
        $(this).tooltip();
    });

    $("#submitButton").click(function(){
        alert("귀하의 이메일로 회원가입 인증 메일이 전송되었습니다. 전송받은 이메일로 가셔서 회원가입 절차를 완료해주시길 바랍니다.");
    });

//   $(function() {
	$(".faq").faq();


//  $(function() {
	$(".slide_gallery").bxSlider({
		auto:true, 
		autoControls:true, 
		speed:4000, 
		pause:1000,
		stopAutoOnClick:true, 
		pager:true 
	});
// });


});