package com.springbook.crud;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ArticleDAO {
	
	private SqlSessionTemplate mybatis;
	
	public ArticleDAO() { }
	
	@Autowired
	public ArticleDAO(SqlSessionTemplate mybatis) {
		this.mybatis = mybatis;
	}
	
	public void insert(ArticleBean vo) {
		System.out.println("##[ArticleDAO.insert]");
		mybatis.insert("ArticleDAO.insert", vo);
	}
	
	public void update(ArticleBean vo) {
		System.out.println("##[ArticleDAO.update]");
		mybatis.update("ArticleDAO.update", vo);
	}
	
	public void delete(ArticleBean vo) {
		System.out.println("##[ArticleDAO.delete]");
		mybatis.delete("ArticleDAO.delete", vo);
	}
	
	public ArticleBean getArticle() {
		System.out.println("##[ArticleDAO.getArticle]");
		return mybatis.selectOne("ArticleDAO.getArticle"); 
	}

}
