package com.springbook.crud;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ArticleController {
	
	@Autowired
	private ArticleService articleService;
	
	@RequestMapping("/insert.do")
	public String insert(ArticleBean vo) {
		articleService.insert(vo);
		return "insertSuccess.jsp";
	}
	
	@RequestMapping("/update.do")
	public String update(ArticleBean vo) {
		articleService.update(vo);
		return "updateSuccess.jsp";
	}
	
	@RequestMapping("/delete.do")
	public String delete(ArticleBean vo) {
		articleService.delete(vo);
		return "deleteSuccess.jsp";
	}
	
	@RequestMapping("/getArticle.do")
	public String getArticle(ArticleBean vo) {
		return "readArticle.jsp";
	}
	
}
