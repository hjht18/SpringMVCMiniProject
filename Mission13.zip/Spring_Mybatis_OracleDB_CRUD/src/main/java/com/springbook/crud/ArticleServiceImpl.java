package com.springbook.crud;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("ArticleService")
public class ArticleServiceImpl implements ArticleService {
	
	@Autowired
	private ArticleDAO articleDAO;

	@Override
	public ArticleBean getArticle() {
		return articleDAO.getArticle();
	}

	@Override
	public void insert(ArticleBean vo) {
		articleDAO.insert(vo);
	}

	@Override
	public void update(ArticleBean vo) {
		articleDAO.update(vo);
	}

	@Override
	public void delete(ArticleBean vo) {
		articleDAO.delete(vo);
	}

}
