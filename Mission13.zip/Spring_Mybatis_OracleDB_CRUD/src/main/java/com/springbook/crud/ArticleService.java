package com.springbook.crud;

public interface ArticleService {
	
	public ArticleBean getArticle();
	
	public void insert(ArticleBean vo);
	
	public void update(ArticleBean vo);
	
	public void delete(ArticleBean vo);


}
